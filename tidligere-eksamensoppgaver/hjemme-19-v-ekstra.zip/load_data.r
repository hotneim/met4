rm(list = ls())

# Loads libraries. You might need to run install.packages("packagename")
# first, where you replace packagename with the package you are missing. 
library(dplyr)
library(magrittr)
library(forcats)
library(stringr)
library(lubridate)

Date.to.numeric <-
  function(date, format) {
    # Function that formats a date into a number, indicating e.g. weekdays,
    #  months, etc, as specified by the "format"-argument.
    strftime(date, format = format) %>%
      as.numeric()
  }

Cond.to.factor <-
  function(condition, true_value, false_value) {
    # Function that tests the condition, and returns either the true or false 
    # value dependent on if the condition is true. Returns a factor.
    ifelse(condition, true_value, false_value) %>%
      factor()
  }

Merge.weekdays.holidays <-
  function(holidays, weekdays) {
    # Function that takes as input a a variable over weekdays and holidays, and
    # returns a factor with levels indicating either the day or the week - or if
    # it is a holiday - it returns the value "holiday".
    case_when(!is.na(holidays) ~ "holiday",
              TRUE ~ as.character(weekdays)) %>%
      factor(.,
             c(levels(weekdays), "holiday"))
  }

# Reads in the holiday-file:
df.holidays <-
  read.csv2("holiday.csv") %>%
  mutate(date = as.Date(date))

# Reads in the traffic-file. Deletes irrelevant rows, and reformats data to 
# prepare it for analysis. Thereafter, combine the dataframe with the 
# "holidays"-dataframe, and adds a variable weekday.holiday identifies weekdays 
# and holidays.
df.traffic <-
  read.csv2("sotrabroen.csv") %>%
  filter(Felt == "Totalt i retning LODDEFJORD") %>%
  droplevels() %>%
  transmute(
    from.time     = as.POSIXct(Fra, format = "%Y-%m-%dT%H:%M"),
    to.time       = as.POSIXct(Til, format = "%Y-%m-%dT%H:%M"),
    date          = as.Date(as.POSIXct(Til, format = "%Y-%m-%dT%H:%M")),
    tariff.change = Cond.to.factor(from.time < '2018-06-01', "Before", "After"),
    hourly.volume = as.numeric(Volum),
    day           = Date.to.numeric(from.time, format = "%d"),
    hour          = Date.to.numeric(from.time, format = "%H"),
    month         = Date.to.numeric(from.time, format = "%m"),
    year          = Date.to.numeric(from.time, format = "%Y"),
    weeknumber    = Date.to.numeric(from.time, format = "%W"),
    weekday       = wday(date, label = TRUE, week_start = 1, abbr = F)
  ) %>%
  left_join(df.holidays, by = c("date" = "date")) %>%
  mutate(weekday.holiday = Merge.weekdays.holidays(holiday, weekday))